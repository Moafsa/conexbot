<?php
/*
Plugin Name: Conext AI SEO Optimizer
Plugin URI: https://conext.click
Description: Automatically optimizes your posts, pages, and WooCommerce products using Google Gemini, OpenAI, or Anthropic Claude APIs with auto-healing key fallback, local sitemap relationship graph, real-time Graphify JSON exporting, GEO (Generative Engine Optimization), and RankMath/Yoast integration.
Version: 1.5.0
Author: Conext
Author URI: https://conext.click
License: GPL2
Text Domain: conext-ai-seo
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Conext_AI_SEO_Optimizer {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        // Init hooks
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        
        // Auto-optimize hooks
        add_action('save_post', [$this, 'auto_optimize_on_save'], 99, 3);
        
        // Image SEO hooks
        add_filter('wp_handle_upload_prefilter', [$this, 'seo_rename_upload_filename']);
        add_action('add_attachment', [$this, 'seo_set_image_metadata']);

        // Editor Sidebar / Meta Box hooks for individual optimization
        add_action('add_meta_boxes', [$this, 'add_individual_seo_meta_box']);
        add_action('wp_ajax_ai_seo_optimize_single_post_editor', [$this, 'ajax_optimize_single_post_editor']);

        // AJAX Handlers for bulk list
        add_action('wp_ajax_ai_seo_get_posts_to_optimize', [$this, 'ajax_get_posts_to_optimize']);
        add_action('wp_ajax_ai_seo_optimize_post', [$this, 'ajax_optimize_post']);

        // Dynamic Real-Time Graph Endpoints (Graphify)
        add_action('init', [$this, 'handle_dynamic_graph_request']);
        add_action('generate_rewrite_rules', [$this, 'add_graph_rewrite_rules']);
    }

    /**
     * Load Plugin Textdomain for Multilingual Translation
     */
    public function load_textdomain() {
        load_plugin_textdomain('conext-ai-seo', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /**
     * Register Admin Menu
     */
    public function register_admin_menu() {
        add_menu_page(
            __('Conext AI SEO', 'conext-ai-seo'),
            __('Conext AI SEO', 'conext-ai-seo'),
            'manage_options',
            'conext-ai-seo',
            [$this, 'render_admin_page'],
            'dashicons-performance',
            80
        );
    }

    /**
     * Register Settings
     */
    public function register_settings() {
        register_setting('conext_ai_seo_settings', 'ai_seo_provider');
        register_setting('conext_ai_seo_settings', 'ai_seo_model');
        register_setting('conext_ai_seo_settings', 'ai_seo_gemini_key');
        register_setting('conext_ai_seo_settings', 'ai_seo_openai_key');
        register_setting('conext_ai_seo_settings', 'ai_seo_claude_key');
        register_setting('conext_ai_seo_settings', 'ai_seo_post_types');
        register_setting('conext_ai_seo_settings', 'ai_seo_auto_optimize');
        register_setting('conext_ai_seo_settings', 'ai_seo_rename_images');
        register_setting('conext_ai_seo_settings', 'ai_seo_use_grounding');
    }

    /**
     * Enqueue Admin Assets
     */
    public function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_conext-ai-seo') {
            return;
        }
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }

    /**
     * Add rewrite rules for clean URLs: /conext-graph.json and /conext-graph-report.md
     */
    public function add_graph_rewrite_rules($wp_rewrite) {
        $new_rules = [
            'conext-graph\.json$' => 'index.php?conext_graph=json',
            'conext-graph-report\.md$' => 'index.php?conext_graph=report'
        ];
        $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
    }

    /**
     * Handle dynamic requests for graph.json and graph-report.md
     */
    public function handle_dynamic_graph_request() {
        // Register query var
        add_filter('query_vars', function($vars) {
            $vars[] = 'conext_graph';
            return $vars;
        });

        $type = get_query_var('conext_graph');
        if (empty($type) && isset($_GET['conext_graph'])) {
            $type = sanitize_text_field($_GET['conext_graph']);
        }

        if ($type === 'json') {
            $graph = $this->generate_site_graph_data();
            header('Content-Type: application/json; charset=utf-8');
            header('Access-Control-Allow-Origin: *'); // Allow AI search crawlers to read it directly
            echo wp_json_encode($graph, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        } elseif ($type === 'report') {
            $graph = $this->generate_site_graph_data();
            $report = $this->generate_site_graph_report_content($graph['nodes'], $graph['edges']);
            header('Content-Type: text/markdown; charset=utf-8');
            header('Access-Control-Allow-Origin: *');
            echo $report;
            exit;
        }
    }

    /**
     * Get active Post Types
     */
    public function get_supported_post_types() {
        $post_types = get_post_types(['public' => true], 'objects');
        $exclude = ['attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation'];
        
        $supported = [];
        foreach ($post_types as $slug => $obj) {
            if (!in_array($slug, $exclude)) {
                $supported[$slug] = $obj->label;
            }
        }
        return $supported;
    }

    /**
     * Add Meta Box to Post / Product Editor
     */
    public function add_individual_seo_meta_box() {
        $selected_types = get_option('ai_seo_post_types', ['post', 'page', 'product']);
        foreach ($selected_types as $type) {
            add_meta_box(
                'ai_seo_individual_meta_box',
                __('Conext AI SEO', 'conext-ai-seo'),
                [$this, 'render_meta_box_content'],
                $type,
                'side',
                'high'
            );
        }
    }

    /**
     * Render Meta Box Content
     */
    public function render_meta_box_content($post) {
        $keyphrase = get_post_meta($post->ID, '_yoast_wpseo_focuskw', true);
        if (empty($keyphrase)) {
            $keyphrase = get_post_meta($post->ID, 'rank_math_focus_keyword', true);
        }
        ?>
        <div class="ai-seo-metabox-content">
            <style>
                .ai-seo-mb-btn {
                    background: #10b981;
                    color: #fff;
                    border: none;
                    padding: 8px 12px;
                    font-weight: 600;
                    border-radius: 4px;
                    cursor: pointer;
                    width: 100%;
                    text-align: center;
                    display: block;
                    margin-bottom: 10px;
                }
                .ai-seo-mb-btn:hover { background: #059669; }
                .ai-seo-mb-status {
                    font-size: 11px;
                    color: #64748b;
                    margin-top: 5px;
                }
            </style>
            <p style="margin-top:0;font-size:12px;color:#64748b;">
                Otimize este conteúdo com a IA da Conext (SEO + GEO). Ele analisará concorrentes e reescreverá o título, conteúdo, FAQ e metadados.
            </p>
            <button type="button" class="ai-seo-mb-btn" id="ai-seo-mb-optimize-btn" data-id="<?php echo $post->ID; ?>">Otimizar com IA</button>
            <div id="ai-seo-mb-status-box" class="ai-seo-mb-status">
                Status: <?php echo !empty($keyphrase) ? '✓ Otimizado (Palavra-chave: ' . esc_html($keyphrase) . ')' : 'Não otimizado'; ?>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('#ai-seo-mb-optimize-btn').on('click', function(e) {
                    e.preventDefault();
                    const btn = $(this);
                    const post_id = btn.data('id');
                    btn.prop('disabled', true).text('Otimizando...');
                    $('#ai-seo-mb-status-box').text('Processando conteúdo com IA (SEO + GEO)...');

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ai_seo_optimize_single_post_editor',
                            post_id: post_id
                        },
                        success: function(response) {
                            if (response.success) {
                                btn.prop('disabled', false).text('Reotimizar com IA');
                                $('#ai-seo-mb-status-box').html('<span style="color:#10b981;">✓ Otimizado!</span> Recarregue a página para ver os textos atualizados.');
                                if ($('#yoast-focus-keyword').length) {
                                    $('#yoast-focus-keyword').val(response.data.keyword);
                                }
                            } else {
                                btn.prop('disabled', false).text('Otimizar com IA');
                                $('#ai-seo-mb-status-box').html('<span style="color:#ef4444;">Erro: ' + response.data + '</span>');
                            }
                        },
                        error: function() {
                            btn.prop('disabled', false).text('Otimizar com IA');
                            $('#ai-seo-mb-status-box').html('<span style="color:#ef4444;">Erro na requisição.</span>');
                        }
                    });
                });
            });
        </script>
        <?php
    }

    /**
     * AJAX: Optimize single post in editor screen
     */
    public function ajax_optimize_single_post_editor() {
        if (!current_user_can('edit_post', intval($_POST['post_id']))) {
            wp_send_json_error('Sem permissão.');
        }
        $post_id = intval($_POST['post_id']);
        $result = $this->optimize_post_seo($post_id);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        wp_send_json_success($result);
    }

    /**
     * Render Admin Page
     */
    public function render_admin_page() {
        $provider = get_option('ai_seo_provider', 'gemini');
        $model = get_option('ai_seo_model', 'gemini-2.0-flash');
        $gemini_key = get_option('ai_seo_gemini_key', '');
        $openai_key = get_option('ai_seo_openai_key', '');
        $claude_key = get_option('ai_seo_claude_key', '');
        $selected_types = get_option('ai_seo_post_types', ['post', 'page', 'product']);
        $auto_optimize = get_option('ai_seo_auto_optimize', 'no');
        $rename_images = get_option('ai_seo_rename_images', 'no');
        $use_grounding = get_option('ai_seo_use_grounding', 'yes');
        $supported_types = $this->get_supported_post_types();
        ?>
        <div class="wrap ai-seo-wrap">
            <style>
                .ai-seo-wrap {
                    --bg-dark: #0f172a;
                    --bg-card: #1e293b;
                    --primary: #10b981;
                    --primary-hover: #059669;
                    --text: #f8fafc;
                    --text-muted: #94a3b8;
                    --border: #334155;
                    font-family: 'Outfit', 'Inter', -apple-system, sans-serif;
                    color: var(--text);
                    max-width: 1200px;
                    margin-top: 20px;
                }
                .ai-seo-container {
                    background: var(--bg-card);
                    border: 1px solid var(--border);
                    border-radius: 12px;
                    padding: 24px;
                    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
                }
                .ai-seo-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    border-bottom: 1px solid var(--border);
                    padding-bottom: 16px;
                    margin-bottom: 24px;
                }
                .ai-seo-header h1 {
                    font-size: 24px;
                    font-weight: 700;
                    color: var(--text);
                    margin: 0;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .ai-seo-header h1 span {
                    background: var(--primary);
                    color: #fff;
                    font-size: 11px;
                    padding: 2px 8px;
                    border-radius: 9999px;
                    text-transform: uppercase;
                }
                .ai-seo-tabs {
                    display: flex;
                    gap: 8px;
                    margin-bottom: 20px;
                    border-bottom: 1px solid var(--border);
                    padding-bottom: 1px;
                }
                .ai-seo-tab-btn {
                    background: none;
                    border: none;
                    border-bottom: 2px solid transparent;
                    color: var(--text-muted);
                    padding: 10px 16px;
                    font-size: 14px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s ease;
                }
                .ai-seo-tab-btn:hover { color: var(--text); }
                .ai-seo-tab-btn.active {
                    color: var(--primary);
                    border-bottom-color: var(--primary);
                }
                .ai-seo-tab-content {
                    display: none;
                    animation: fadeIn 0.3s ease-in-out;
                }
                .ai-seo-tab-content.active { display: block; }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(4px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .ai-seo-form-group { margin-bottom: 20px; }
                .ai-seo-form-group label {
                    display: block;
                    font-weight: 600;
                    margin-bottom: 6px;
                    color: var(--text);
                }
                .ai-seo-form-group input[type="text"], 
                .ai-seo-form-group input[type="password"] {
                    width: 100%;
                    max-width: 500px;
                    background: var(--bg-dark);
                    border: 1px solid var(--border);
                    color: var(--text);
                    padding: 10px 12px;
                    border-radius: 6px;
                }
                .ai-seo-form-group select {
                    width: 100%;
                    max-width: 500px;
                    border: 1px solid var(--border);
                    padding: 10px 12px;
                    border-radius: 6px;
                    background-color: #1e293b !important;
                    color: #ffffff !important;
                    cursor: pointer;
                }
                .ai-seo-form-group select option {
                    background-color: #1e293b !important;
                    color: #ffffff !important;
                    padding: 8px;
                }
                .ai-seo-checkbox-list {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                    gap: 10px;
                    background: var(--bg-dark);
                    padding: 16px;
                    border-radius: 8px;
                    border: 1px solid var(--border);
                    max-width: 700px;
                }
                .ai-seo-checkbox-item {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    color: var(--text-muted);
                    cursor: pointer;
                }
                .ai-seo-submit-btn {
                    background: var(--primary);
                    color: #fff;
                    border: none;
                    padding: 12px 24px;
                    font-weight: 600;
                    border-radius: 6px;
                    cursor: pointer;
                    transition: background 0.2s;
                }
                .ai-seo-submit-btn:hover { background: var(--primary-hover); }
                
                /* Bulk Items Table */
                .ai-seo-bulk-controls {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 15px;
                }
                .ai-seo-table-container {
                    max-height: 400px;
                    overflow-y: auto;
                    border: 1px solid var(--border);
                    border-radius: 8px;
                    background: var(--bg-dark);
                    margin-bottom: 20px;
                    display: none;
                }
                .ai-seo-table {
                    width: 100%;
                    border-collapse: collapse;
                    text-align: left;
                    font-size: 13px;
                }
                .ai-seo-table th, .ai-seo-table td {
                    padding: 12px;
                    border-bottom: 1px solid var(--border);
                }
                .ai-seo-table th {
                    background: #0f172a;
                    position: sticky;
                    top: 0;
                    font-weight: 600;
                    color: var(--text);
                    z-index: 10;
                }
                .ai-seo-table tr:hover { background: rgba(255,255,255,0.02); }
                .ai-seo-badge {
                    padding: 2px 8px;
                    border-radius: 4px;
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                }
                .ai-seo-badge.product { background: #06b6d4; color: #fff; }
                .ai-seo-badge.post { background: #3b82f6; color: #fff; }
                .ai-seo-badge.page { background: #8b5cf6; color: #fff; }
                .ai-seo-badge.green { background: #10b981; color: #fff; }
                .ai-seo-badge.grey { background: #64748b; color: #fff; }
                
                .ai-seo-progress-container {
                    margin: 20px 0;
                    display: none;
                }
                .ai-seo-progress-bar {
                    background: var(--border);
                    border-radius: 9999px;
                    height: 12px;
                    overflow: hidden;
                    position: relative;
                }
                .ai-seo-progress-fill {
                    background: var(--primary);
                    height: 100%;
                    width: 0%;
                    transition: width 0.3s ease;
                }
                .ai-seo-progress-text {
                    display: flex;
                    justify-content: space-between;
                    font-size: 13px;
                    color: var(--text-muted);
                    margin-top: 6px;
                }
                .ai-seo-console {
                    background: #000;
                    border: 1px solid var(--border);
                    border-radius: 6px;
                    height: 250px;
                    overflow-y: auto;
                    font-family: monospace;
                    padding: 12px;
                    font-size: 12px;
                    color: #38bdf8;
                }
                .ai-seo-console p { margin: 0 0 6px 0; line-height: 1.4; }
                .ai-seo-console p.success { color: #4ade80; }
                .ai-seo-console p.error { color: #f87171; }
                .ai-seo-console p.info { color: #38bdf8; }

                /* Card Design */
                .ai-seo-card {
                    background: var(--bg-dark);
                    border: 1px solid var(--border);
                    border-radius: 8px;
                    padding: 20px;
                    margin-bottom: 20px;
                }
                .ai-seo-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 20px;
                }
            </style>

            <h1 class="screen-reader-text">Conext AI SEO Optimizer</h1>
            <div class="wp-header-end"></div>

            <div class="ai-seo-container" style="margin-top: 15px;">
                <div class="ai-seo-header">
                    <div class="ai-seo-brand">
                        <span class="dashicons dashicons-performance" style="font-size:24px;width:24px;height:24px;color:var(--primary);vertical-align:middle;"></span>
                        <span style="font-size:22px;font-weight:700;margin-left:8px;vertical-align:middle;color:var(--text);">Conext AI SEO Optimizer <span style="background:var(--primary);color:#fff;font-size:11px;padding:2px 8px;border-radius:9999px;text-transform:uppercase;vertical-align:middle;">PRO</span></span>
                    </div>
                    <p style="margin:0;color:var(--text-muted);font-size:12px;">Powered by Conext & Gemini API with Google Search Grounding</p>
                </div>

                <div class="ai-seo-tabs">
                    <button type="button" class="ai-seo-tab-btn active" data-tab="config">Configurações</button>
                    <button type="button" class="ai-seo-tab-btn" data-tab="bulk">Otimização em Massa / Filtros</button>
                    <button type="button" class="ai-seo-tab-btn" data-tab="graphify">Graphify & GEO</button>
                </div>

                <!-- TAB CONFIG -->
                <div id="ai-seo-tab-config" class="ai-seo-tab-content active">
                    <form method="post" action="options.php">
                        <?php settings_fields('conext_ai_seo_settings'); ?>
                        
                        <div class="ai-seo-form-group">
                            <label for="ai_seo_provider">Provedor de IA</label>
                            <select name="ai_seo_provider" id="ai_seo_provider">
                                <option value="gemini" <?php selected($provider, 'gemini'); ?>>Google Gemini (Recomendado)</option>
                                <option value="openai" <?php selected($provider, 'openai'); ?>>OpenAI</option>
                                <option value="claude" <?php selected($provider, 'claude'); ?>>Anthropic Claude</option>
                            </select>
                        </div>

                        <div class="ai-seo-form-group">
                            <label for="ai_seo_model">Modelo da IA</label>
                            <select name="ai_seo_model" id="ai_seo_model">
                                <!-- Populated dynamically by JS -->
                            </select>
                        </div>

                        <!-- Provider API Keys -->
                        <div class="ai-seo-form-group provider-key-field" id="field-key-gemini">
                            <label for="ai_seo_gemini_key">Chave de API do Gemini</label>
                            <div style="display: flex; gap: 8px; align-items: center; max-width: 500px;">
                                <input type="password" name="ai_seo_gemini_key" id="ai_seo_gemini_key" value="<?php echo esc_attr($gemini_key); ?>" placeholder="Insira sua Gemini API Key" style="width: 100%; max-width: none;">
                                <?php if (!empty($gemini_key)) : ?>
                                    <button type="button" class="button ai-seo-clear-single-key" data-key="gemini" style="background:#ef4444; color:#fff; border:none; height:40px; padding:0 12px; border-radius:6px; cursor:pointer;" title="Excluir esta chave">Excluir</button>
                                <?php endif; ?>
                            </div>
                            <p class="description" style="color:var(--text-muted);">Gere uma chave gratuita no <a href="https://aistudio.google.com/" target="_blank" style="color:var(--primary);">Google AI Studio</a>.</p>
                        </div>

                        <div class="ai-seo-form-group provider-key-field" id="field-key-openai" style="display:none;">
                            <label for="ai_seo_openai_key">Chave de API da OpenAI</label>
                            <div style="display: flex; gap: 8px; align-items: center; max-width: 500px;">
                                <input type="password" name="ai_seo_openai_key" id="ai_seo_openai_key" value="<?php echo esc_attr($openai_key); ?>" placeholder="sk-..." style="width: 100%; max-width: none;">
                                <?php if (!empty($openai_key)) : ?>
                                    <button type="button" class="button ai-seo-clear-single-key" data-key="openai" style="background:#ef4444; color:#fff; border:none; height:40px; padding:0 12px; border-radius:6px; cursor:pointer;" title="Excluir esta chave">Excluir</button>
                                <?php endif; ?>
                            </div>
                            <p class="description" style="color:var(--text-muted);">Gere em <a href="https://platform.openai.com/api-keys" target="_blank" style="color:var(--primary);">OpenAI Platform</a>.</p>
                        </div>

                        <div class="ai-seo-form-group provider-key-field" id="field-key-claude" style="display:none;">
                            <label for="ai_seo_claude_key">Chave de API do Claude (Anthropic)</label>
                            <div style="display: flex; gap: 8px; align-items: center; max-width: 500px;">
                                <input type="password" name="ai_seo_claude_key" id="ai_seo_claude_key" value="<?php echo esc_attr($claude_key); ?>" placeholder="sk-ant-..." style="width: 100%; max-width: none;">
                                <?php if (!empty($claude_key)) : ?>
                                    <button type="button" class="button ai-seo-clear-single-key" data-key="claude" style="background:#ef4444; color:#fff; border:none; height:40px; padding:0 12px; border-radius:6px; cursor:pointer;" title="Excluir esta chave">Excluir</button>
                                <?php endif; ?>
                            </div>
                            <p class="description" style="color:var(--text-muted);">Gere em <a href="https://console.anthropic.com/" target="_blank" style="color:var(--primary);">Anthropic Console</a>.</p>
                        </div>

                        <div class="ai-seo-form-group">
                            <label>Tipos de Postagem Suportados</label>
                            <div class="ai-seo-checkbox-list">
                                <?php foreach ($supported_types as $slug => $label) : ?>
                                    <label class="ai-seo-checkbox-item">
                                        <input type="checkbox" name="ai_seo_post_types[]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug, $selected_types)); ?>>
                                        <?php echo esc_html($label); ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="ai-seo-form-group" id="field-google-grounding">
                            <label class="ai-seo-checkbox-item">
                                <input type="checkbox" name="ai_seo_use_grounding" value="yes" <?php checked($use_grounding, 'yes'); ?>>
                                <strong>Pesquisa Google Grounding (Exclusivo Gemini):</strong> IA pesquisa concorrentes e termos de busca reais do mercado no Google em tempo real.
                            </label>
                        </div>

                        <div class="ai-seo-form-group">
                            <label class="ai-seo-checkbox-item">
                                <input type="checkbox" name="ai_seo_auto_optimize" value="yes" <?php checked($auto_optimize, 'yes'); ?>>
                                Otimizar automaticamente novas páginas/produtos criados ao salvar
                            </label>
                        </div>

                        <div class="ai-seo-form-group">
                            <label class="ai-seo-checkbox-item">
                                <input type="checkbox" name="ai_seo_rename_images" value="yes" <?php checked($rename_images, 'yes'); ?>>
                                Renomear automaticamente arquivos de imagem no upload para slugs amigáveis
                            </label>
                        </div>

                        <div style="margin-top: 30px; display: flex; gap: 12px; align-items: center;">
                            <?php submit_button(__('Salvar Configurações', 'universal-ai-seo'), 'primary', 'submit', false, ['class' => 'ai-seo-submit-btn']); ?>
                            <button type="button" class="ai-seo-submit-btn" id="ai-seo-clear-keys-btn" style="background:#ef4444;">Limpar Chaves de API</button>
                        </div>
                    </form>
                </div>

                <!-- TAB BULK -->
                <div id="ai-seo-tab-bulk" class="ai-seo-tab-content">
                    <div class="ai-seo-bulk-card" style="margin-bottom:15px;">
                        <h3 style="margin-top:0;">Filtro de Otimização</h3>
                        <p style="color:var(--text-muted);margin-bottom:15px;">
                            Faça a varredura para selecionar individualmente as páginas, posts ou produtos que deseja otimizar. Os itens que você desmarcar não sofrerão alterações.
                        </p>
                        <button type="button" id="ai-seo-scan-btn" class="ai-seo-submit-btn" style="background:#3b82f6;">Carregar Lista de Itens</button>
                    </div>

                    <div class="ai-seo-bulk-controls" id="ai-seo-bulk-controls-box" style="display:none;">
                        <div>
                            <input type="checkbox" id="ai-seo-select-all" checked> <label for="ai-seo-select-all" style="font-weight:600;cursor:pointer;">Selecionar Todos</label>
                        </div>
                        <div>
                            <button type="button" id="ai-seo-bulk-btn" class="ai-seo-submit-btn">Otimizar Itens Selecionados</button>
                        </div>
                    </div>

                    <!-- Items Table -->
                    <div class="ai-seo-table-container" id="ai-seo-table-box">
                        <table class="ai-seo-table">
                            <thead>
                                <tr>
                                    <th width="40">Select</th>
                                    <th>Título</th>
                                    <th>Tipo</th>
                                    <th>SEO Atual (Yoast/RM)</th>
                                </tr>
                            </thead>
                            <tbody id="ai-seo-table-body">
                                <!-- Loaded dynamically via JS -->
                            </tbody>
                        </table>
                    </div>

                    <div class="ai-seo-progress-container" id="ai-seo-progress-box">
                        <div class="ai-seo-progress-bar">
                            <div class="ai-seo-progress-fill" id="ai-seo-progress-bar-fill"></div>
                        </div>
                        <div class="ai-seo-progress-text">
                            <span id="ai-seo-progress-count">Processando: 0 / 0</span>
                            <span id="ai-seo-progress-percentage">0%</span>
                        </div>
                    </div>

                    <h3 style="margin-top:20px;">Log de Atividade</h3>
                    <div class="ai-seo-console" id="ai-seo-console-box">
                        <p class="info">[Console] Pronto para carregar conteúdo...</p>
                    </div>
                </div>

                <!-- TAB GRAPHIFY -->
                <div id="ai-seo-tab-graphify" class="ai-seo-tab-content">
                    <div class="ai-seo-grid">
                        <div class="ai-seo-card">
                            <h3 style="margin-top:0;"><span class="dashicons dashicons-share" style="vertical-align:middle;margin-right:6px;"></span> Grafo de Conhecimento Dinâmico (Graphify)</h3>
                            <p style="color:var(--text-muted);font-size:13px;line-height:1.5;">
                                Seu site agora possui um **Grafo de Conhecimento Dinâmico e 100% Automático** compatível com o **Graphify Labs** e motores de RAG!
                            </p>
                            <p style="color:var(--text-muted);font-size:13px;line-height:1.5;">
                                A estrutura de relacionamentos (páginas, produtos, categorias e conexões) é atualizada em tempo real sempre que seu site muda, e é disponibilizada em URLs públicas amigáveis para crawlers de IA (OpenAI, Claude, Perplexity) consumirem e indexarem o site diretamente.
                            </p>
                            
                            <div style="margin-top:20px;background:var(--bg-card);border:1px solid var(--border);padding:12px;border-radius:6px;">
                                <h4 style="margin:0 0 10px 0;color:var(--primary);">✓ Links do Grafo Automático (Tempo Real):</h4>
                                <ul style="margin:0;padding-left:18px;font-size:13px;line-height:1.8;">
                                    <li><strong>Grafo em Tempo Real (JSON):</strong> <br><a href="<?php echo home_url('/conext-graph.json'); ?>" target="_blank" style="color:#60a5fa;word-break:break-all;"><?php echo home_url('/conext-graph.json'); ?></a></li>
                                    <li><strong>Relatório Semântico (Markdown):</strong> <br><a href="<?php echo home_url('/conext-graph-report.md'); ?>" target="_blank" style="color:#60a5fa;word-break:break-all;"><?php echo home_url('/conext-graph-report.md'); ?></a></li>
                                </ul>
                                <p style="margin:10px 0 0 0;font-size:11px;color:var(--text-muted);">
                                    * Se os links amigáveis acima retornarem 404 devido às configurações de URL do seu servidor, utilize os caminhos alternativos diretos:<br>
                                    JSON: <a href="<?php echo home_url('/?conext_graph=json'); ?>" target="_blank" style="color:#60a5fa;"><?php echo home_url('/?conext_graph=json'); ?></a><br>
                                    MD: <a href="<?php echo home_url('/?conext_graph=report'); ?>" target="_blank" style="color:#60a5fa;"><?php echo home_url('/?conext_graph=report'); ?></a>
                                </p>
                            </div>
                        </div>

                        <div class="ai-seo-card">
                            <h3 style="margin-top:0;"><span class="dashicons dashicons-translation" style="vertical-align:middle;margin-right:6px;"></span> GEO (Generative Engine Optimization)</h3>
                            <p style="color:var(--text-muted);font-size:13px;line-height:1.5;">
                                O plugin otimiza o conteúdo das suas postagens e produtos de acordo com os critérios mais recentes de indexação de **Motores de Busca Inteligentes** (ChatGPT Search, Perplexity e Gemini):
                            </p>
                            <ul style="color:var(--text-muted);font-size:12px;line-height:1.6;padding-left:18px;">
                                <li><strong>Resumos TL;DR:</strong> Adiciona um resumo executivo de 2 frases no topo da página (ideal para rastreamento semântico rápido).</li>
                                <li><strong>Estruturas FAQPage:</strong> Cria perguntas e respostas curtas e diretas ao final (ideal para respostas diretas em RAG).</li>
                                <li><strong>Tabelas de Comparação:</strong> Organiza especificações técnicas em estruturas tabulares legíveis para IAs.</li>
                                <li><strong>Citações de Autoridade:</strong> Inserção de links de saída (outbound links) para portais reconhecidos.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            jQuery(document).ready(function($) {
                // Provider-model map
                const modelsByProvider = {
                    gemini: [
                        { value: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash (Rápido e Econômico)' },
                        { value: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash (Avançado)' },
                        { value: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro (Máxima Inteligência)' }
                    ],
                    openai: [
                        { value: 'gpt-4o-mini', label: 'GPT-4o Mini (Veloz e Econômico)' },
                        { value: 'gpt-4o', label: 'GPT-4o (Modelo Avançado Completo)' },
                        { value: 'o4-mini', label: 'o4-mini (Raciocínio Avançado)' }
                    ],
                    claude: [
                        { value: 'claude-sonnet-4-6', label: 'Claude Sonnet 4.6 (Excelente Redação)' },
                        { value: 'claude-haiku-4-5-20251001', label: 'Claude Haiku 4.5 (Rápido e Preciso)' },
                        { value: 'claude-opus-4-5-20251101', label: 'Claude Opus 4.5 (Máxima Inteligência)' }
                    ]
                };

                const activeModel = '<?php echo esc_js($model); ?>';

                function updateModelDropdown(provider) {
                    const dropdown = $('#ai_seo_model');
                    dropdown.empty();
                    const models = modelsByProvider[provider] || [];
                    models.forEach(function(m) {
                        const selected = m.value === activeModel ? 'selected' : '';
                        dropdown.append(`<option value="${m.value}" ${selected}>${m.label}</option>`);
                    });
                }

                function handleProviderFields(provider) {
                    $('.provider-key-field').hide();
                    $('#field-key-' + provider).show();

                    if (provider === 'gemini') {
                        $('#field-google-grounding').show();
                    } else {
                        $('#field-google-grounding').hide();
                    }
                }

                // Initial load triggers
                const initialProvider = $('#ai_seo_provider').val();
                updateModelDropdown(initialProvider);
                handleProviderFields(initialProvider);

                // On change trigger
                $('#ai_seo_provider').on('change', function() {
                    const prov = $(this).val();
                    updateModelDropdown(prov);
                    handleProviderFields(prov);
                });

                // Clear API Keys trigger
                $('#ai-seo-clear-keys-btn').on('click', function(e) {
                    e.preventDefault();
                    if (confirm('Tem certeza de que deseja apagar todas as chaves de API salvas?')) {
                        $('#ai_seo_gemini_key').val('');
                        $('#ai_seo_openai_key').val('');
                        $('#ai_seo_claude_key').val('');
                        $(this).closest('form').submit();
                    }
                });

                // Clear single API Key
                $('.ai-seo-clear-single-key').on('click', function(e) {
                    e.preventDefault();
                    const keyType = $(this).data('key');
                    let keyLabel = 'do Gemini';
                    if (keyType === 'openai') keyLabel = 'da OpenAI';
                    if (keyType === 'claude') keyLabel = 'do Claude';
                    
                    if (confirm('Tem certeza de que deseja apagar a chave ' + keyLabel + '?')) {
                        $('#ai_seo_' + keyType + '_key').val('');
                        $(this).closest('form').submit();
                    }
                });

                // Tab switching
                $('.ai-seo-tab-btn').on('click', function() {
                    $('.ai-seo-tab-btn').removeClass('active');
                    $('.ai-seo-tab-content').removeClass('active');
                    
                    $(this).addClass('active');
                    $('#ai-seo-tab-' + $(this).data('tab')).addClass('active');
                });

                let loadedPosts = [];
                let selectedPosts = [];
                let currentIndex = 0;
                let isProcessing = false;

                function writeConsole(msg, type = 'info') {
                    const consoleBox = $('#ai-seo-console-box');
                    const time = new Date().toLocaleTimeString();
                    const line = $('<p>').addClass(type).text(`[${time}] ${msg}`);
                    consoleBox.append(line);
                    consoleBox.scrollTop(consoleBox[0].scrollHeight);
                }

                // Scan Action
                $('#ai-seo-scan-btn').on('click', function() {
                    writeConsole('Carregando itens do banco de dados...', 'info');
                    $(this).prop('disabled', true).text('Buscando...');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ai_seo_get_posts_to_optimize',
                        },
                        success: function(response) {
                            $('#ai-seo-scan-btn').prop('disabled', false).text('Carregar Lista de Itens');
                            if (response.success) {
                                loadedPosts = response.data;
                                writeConsole(`Varredura concluída. Encontrados ${loadedPosts.length} itens no total.`, 'success');
                                renderTable(loadedPosts);
                            } else {
                                writeConsole('Erro ao varrer banco: ' + response.data, 'error');
                            }
                        },
                        error: function() {
                            $('#ai-seo-scan-btn').prop('disabled', false).text('Carregar Lista de Itens');
                            writeConsole('Erro na requisição AJAX de varredura.', 'error');
                        }
                    });
                });

                function renderTable(items) {
                    const tbody = $('#ai-seo-table-body');
                    tbody.empty();
                    
                    if (items.length === 0) {
                        tbody.append('<tr><td colspan="4" style="text-align:center;">Nenhum item encontrado para otimização.</td></tr>');
                        $('#ai-seo-table-box').show();
                        $('#ai-seo-bulk-controls-box').hide();
                        return;
                    }

                    items.forEach(function(item) {
                        const typeBadge = `<span class="ai-seo-badge ${item.type}">${item.type_label}</span>`;
                        const seoBadge = item.is_optimized ? 
                            `<span class="ai-seo-badge green">✓ ${item.focuskw}</span>` : 
                            `<span class="ai-seo-badge grey">Não Otimizado</span>`;

                        const row = `
                            <tr>
                                <td><input type="checkbox" class="ai-seo-item-checkbox" value="${item.id}" checked></td>
                                <td><strong>${item.title}</strong></td>
                                <td>${typeBadge}</td>
                                <td>${seoBadge}</td>
                            </tr>
                        `;
                        tbody.append(row);
                    });

                    $('#ai-seo-table-box').show();
                    $('#ai-seo-bulk-controls-box').show();
                }

                // Select / Deselect All
                $('#ai-seo-select-all').on('change', function() {
                    $('.ai-seo-item-checkbox').prop('checked', $(this).is(':checked'));
                });

                // Start Bulk Action
                $('#ai-seo-bulk-btn').on('click', function() {
                    if (isProcessing) return;
                    
                    selectedPosts = [];
                    $('.ai-seo-item-checkbox:checked').each(function() {
                        const id = parseInt($(this).val());
                        const item = loadedPosts.find(p => p.id === id);
                        if (item) {
                            selectedPosts.push(item);
                        }
                    });

                    if (selectedPosts.length === 0) {
                        writeConsole('Erro: Nenhum produto ou postagem selecionada para otimização.', 'error');
                        alert('Selecione pelo menos um item da tabela para começar.');
                        return;
                    }

                    isProcessing = true;
                    $(this).prop('disabled', true).text('Otimizando...');
                    $('#ai-seo-scan-btn').prop('disabled', true);
                    $('.ai-seo-item-checkbox').prop('disabled', true);
                    
                    $('#ai-seo-progress-box').show();
                    currentIndex = 0;
                    updateProgress();
                    optimizeNext();
                });

                function updateProgress() {
                    const total = selectedPosts.length;
                    const percent = total > 0 ? Math.round((currentIndex / total) * 100) : 0;
                    $('#ai-seo-progress-bar-fill').css('width', percent + '%');
                    $('#ai-seo-progress-count').text(`Processando: ${currentIndex} / ${total}`);
                    $('#ai-seo-progress-percentage').text(percent + '%');
                }

                function optimizeNext() {
                    if (currentIndex >= selectedPosts.length) {
                        isProcessing = false;
                        $('#ai-seo-bulk-btn').prop('disabled', false).text('Otimizar Itens Selecionados');
                        $('#ai-seo-scan-btn').prop('disabled', false);
                        $('.ai-seo-item-checkbox').prop('disabled', false);
                        writeConsole('PROCESSO DE OTIMIZAÇÃO EM MASSA CONCLUÍDO!', 'success');
                        return;
                    }

                    const post = selectedPosts[currentIndex];
                    writeConsole(`Otimizando item (${currentIndex + 1}/${selectedPosts.length}) ID ${post.id} com SEO/GEO...`, 'info');

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ai_seo_optimize_post',
                            post_id: post.id
                        },
                        success: function(response) {
                            if (response.success) {
                                writeConsole(`ID ${post.id} otimizado! Foco definido para: "${response.data.keyword}". Yoast/RankMath atualizados.`, 'success');
                            } else {
                                writeConsole(`ID ${post.id} falhou: ${response.data}`, 'error');
                            }
                            currentIndex++;
                            updateProgress();
                            optimizeNext();
                        },
                        error: function() {
                            writeConsole(`ID ${post.id} falhou devido a erro de rede/AJAX.`, 'error');
                            currentIndex++;
                            updateProgress();
                            optimizeNext();
                        }
                    });
                }
            });
        </script>
        <?php
    }

    /**
     * AJAX: Get posts lists with SEO metadata
     */
    public function ajax_get_posts_to_optimize() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permissão negada.');
        }

        $selected_types = get_option('ai_seo_post_types', ['post', 'page', 'product']);
        $post_type_objects = get_post_types([], 'objects');
        
        $query = new WP_Query([
            'post_type' => $selected_types,
            'posts_per_page' => -1,
            'post_status' => ['publish', 'draft', 'private'],
        ]);

        $posts = [];
        if ($query->have_posts()) {
            foreach ($query->posts as $post) {
                $focuskw = get_post_meta($post->ID, '_yoast_wpseo_focuskw', true);
                if (empty($focuskw)) {
                    $focuskw = get_post_meta($post->ID, 'rank_math_focus_keyword', true);
                }
                
                $posts[] = [
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'type' => $post->post_type,
                    'type_label' => $post_type_objects[$post->post_type]->labels->singular_name ?? $post->post_type,
                    'is_optimized' => !empty($focuskw),
                    'focuskw' => $focuskw
                ];
            }
        }

        wp_send_json_success($posts);
    }

    /**
     * AJAX: Optimize single post
     */
    public function ajax_optimize_post() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permissão negada.');
        }

        $post_id = intval($_POST['post_id'] ?? 0);
        if (!$post_id) {
            wp_send_json_error('ID de post inválido.');
        }

        $result = $this->optimize_post_seo($post_id);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        wp_send_json_success($result);
    }

    /**
     * Unified AI API caller wrapper supporting Gemini, OpenAI, and Claude with fallback loop
     */
    public function call_ai_api($prompt, $system_instruction) {
        $selected_provider = get_option('ai_seo_provider', 'gemini');
        
        // Define priority order of providers to try, starting with the selected one
        $providers_to_try = [$selected_provider];
        $all_providers = ['gemini', 'openai', 'claude'];
        foreach ($all_providers as $p) {
            if ($p !== $selected_provider) {
                $providers_to_try[] = $p;
            }
        }
        
        $errors = [];
        
        foreach ($providers_to_try as $provider) {
            // Check if key is configured and set defaults for models
            $key = '';
            if ($provider === 'gemini') {
                $key = get_option('ai_seo_gemini_key', '');
                $model = get_option('ai_seo_model', 'gemini-2.0-flash');
                if (strpos($model, 'gemini') === false) {
                    $model = 'gemini-2.0-flash';
                }
            } elseif ($provider === 'openai') {
                $key = get_option('ai_seo_openai_key', '');
                $model = get_option('ai_seo_model', 'gpt-4o-mini');
                if (strpos($model, 'gpt') === false) {
                    $model = 'gpt-4o-mini';
                }
            } elseif ($provider === 'claude') {
                $key = get_option('ai_seo_claude_key', '');
                $model = get_option('ai_seo_model', 'claude-sonnet-4-6');
                if (strpos($model, 'claude') === false) {
                    $model = 'claude-sonnet-4-6';
                }
            }
            
            if (empty($key)) {
                $errors[] = "[{$provider}]: Chave API vazia.";
                continue;
            }
            
            // Try calling the provider
            $result = $this->call_single_provider_api($provider, $model, $key, $prompt, $system_instruction);
            
            if (!is_wp_error($result)) {
                return $result; // Success! Return immediately.
            } else {
                $errors[] = "[{$provider} falhou]: " . $result->get_error_message();
            }
        }
        
        // If we reach here, all providers failed
        return new WP_Error('all_providers_failed', 'Todos os provedores configurados falharam na tentativa de otimização: ' . implode(' | ', $errors));
    }

    /**
     * Call a single AI API provider
     */
    private function call_single_provider_api($provider, $model, $key, $prompt, $system_instruction) {
        if ($provider === 'gemini') {
            $use_grounding = get_option('ai_seo_use_grounding', 'yes');
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . esc_attr($key);
            
            $payload = [
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $prompt]
                        ]
                    ]
                ],
                'systemInstruction' => [
                    'parts' => [
                        ['text' => $system_instruction]
                    ]
                ]
            ];
            
            if ($use_grounding === 'yes') {
                $payload['tools'] = [
                    [
                        'google_search' => new stdClass()
                    ]
                ];
            } else {
                $payload['generationConfig'] = [
                    'responseMimeType' => 'application/json'
                ];
            }
            
            $response = wp_remote_post($url, [
                'headers'     => ['Content-Type' => 'application/json'],
                'body'        => wp_json_encode($payload),
                'timeout'     => 60,
            ]);
            
            if (is_wp_error($response)) {
                return $response;
            }
            
            $code = wp_remote_retrieve_response_code($response);
            if ($code !== 200) {
                return new WP_Error('api_error', "Status {$code}: " . wp_remote_retrieve_body($response));
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $raw_text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
            
            return $this->extract_json_from_text($raw_text);

        } elseif ($provider === 'openai') {
            $url = 'https://api.openai.com/v1/chat/completions';
            
            $payload = [
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $system_instruction],
                    ['role' => 'user', 'content' => $prompt]
                ],
                'response_format' => ['type' => 'json_object']
            ];
            
            $response = wp_remote_post($url, [
                'headers'     => [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . esc_attr($key)
                ],
                'body'        => wp_json_encode($payload),
                'timeout'     => 60,
            ]);
            
            if (is_wp_error($response)) {
                return $response;
            }
            
            $code = wp_remote_retrieve_response_code($response);
            if ($code !== 200) {
                return new WP_Error('api_error', "Status {$code}: " . wp_remote_retrieve_body($response));
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $raw_text = $data['choices'][0]['message']['content'] ?? '';
            
            return $this->extract_json_from_text($raw_text);

        } elseif ($provider === 'claude') {
            $url = 'https://api.anthropic.com/v1/messages';
            
            $payload = [
                'model' => $model,
                'max_tokens' => 4000,
                'system' => $system_instruction,
                'messages' => [
                    ['role' => 'user', 'content' => $prompt]
                ]
            ];
            
            $response = wp_remote_post($url, [
                'headers'     => [
                    'Content-Type' => 'application/json',
                    'x-api-key' => esc_attr($key),
                    'anthropic-version' => '2023-06-01'
                ],
                'body'        => wp_json_encode($payload),
                'timeout'     => 60,
            ]);
            
            if (is_wp_error($response)) {
                return $response;
            }
            
            $code = wp_remote_retrieve_response_code($response);
            if ($code !== 200) {
                return new WP_Error('api_error', "Status {$code}: " . wp_remote_retrieve_body($response));
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            $raw_text = $data['content'][0]['text'] ?? '';
            
            return $this->extract_json_from_text($raw_text);
        }
        
        return new WP_Error('invalid_provider', 'Provedor desconhecido.');
    }

    /**
     * Regex extractor to pull JSON blocks out of text safely
     */
    private function extract_json_from_text($text) {
        if (preg_match('/\{.*\}/s', $text, $matches)) {
            $json_str = $matches[0];
            $decoded = json_decode($json_str, true);
            if (!empty($decoded)) {
                return $decoded;
            }
        }
        return new WP_Error('json_parse_failed', 'Não foi possível extrair um JSON válido da resposta: ' . esc_html(substr($text, 0, 150)));
    }

    /**
     * The core SEO/GEO Optimizer routine
     */
    public function optimize_post_seo($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('not_found', 'Postagem não encontrada.');
        }

        $title = $post->post_title;
        $content = strip_shortcodes(wp_strip_all_tags($post->post_content));
        $post_type = $post->post_type;

        // Fetch categories
        $categories = [];
        if ($post_type === 'product') {
            $terms = get_the_terms($post_id, 'product_cat');
        } else {
            $terms = get_the_terms($post_id, 'category');
        }
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $t) {
                $categories[] = $t->name;
            }
        }
        $cat_list = implode(', ', $categories);

        // Fetch related internal links using the local database relationship graph
        $related_links = $this->get_related_internal_links($post_id, $title, $content);
        $links_prompt = "";
        foreach ($related_links as $l) {
            $links_prompt .= "- \"{$l['anchor']}\" -> {$l['url']}\n";
        }

        // Detect site locale
        $site_locale = get_locale();
        $locale_short = substr($site_locale, 0, 2);

        // System Instruction implementing Yoast and GEO/LLM guidelines
        if ($locale_short === 'pt') {
            $system_instruction = "Você é um Especialista de Alto Nível em SEO Técnico, GEO (Generative Engine Optimization) e Redação Comercial para IAs.
Sua missão é otimizar as postagens, páginas e produtos com base em diretrizes de SEO clássico, E-E-A-T e otimização para indexação de Motores de Resposta de IA (como ChatGPT Search, Claude e Perplexity):

1. Idioma: Todo o conteúdo gerado (incluindo foco, título, descrição, conteúdo otimizado, resumo e alt text) deve ser escrito obrigatoriamente em Português.
2. E-E-A-T (Experiência, Expertise, Autoridade, Confiança): O conteúdo reescrito deve demonstrar profundo conhecimento técnico. Evite frases genéricas e clichés típicos de assistentes de IA.
3. Tamanho e Legibilidade (Yoast Readability):
   - O texto final gerado deve ser completo, rico em detalhes e ter obrigatoriamente entre 350 e 600 palavras.
   - Tamanho das Sentenças: Mantenha as sentenças curtas e objetivas (máximo de 20 palavras por frase). Evite períodos longos e complexos. Pelo menos 75% das sentenças devem ter menos de 20 palavras.
   - Palavras de Transição: Use uma altíssima densidade de palavras de transição (como 'além disso', 'portanto', 'contudo', 'entretanto', 'por exemplo', 'dessa forma', 'consequentemente', 'assim', 'por outro lado', 'adicionalmente', 'como resultado') para conectar as frases e parágrafos de forma fluida. Pelo menos 30% das frases geradas devem conter obrigatoriamente palavras de transição para garantir a legibilidade máxima do Yoast.
4. Palavra-chave em Foco (Yoast/RankMath): Defina a palavra-chave ideal baseada no volume e nas tendências do mercado (1 a 4 palavras no máximo).
5. Título SEO: Crie um título SEO impactante com 50 a 60 caracteres. A palavra-chave em foco deve estar no início do título.
6. Meta Descrição: Escreva uma meta descrição persuasiva de 120 a 160 caracteres contendo a palavra-chave.
7. Estrutura de Subtítulos: Organize o texto usando H2 e H3 de forma lógica. Pelo menos um dos subcabeçalhos H2 ou H3 deve conter a palavra-chave em foco ou um sinônimo muito próximo.
8. Otimização para IAs e Treinamento (GEO):
   - TL;DR (Resumo Executivo): Adicione um bloco de resumo rápido em itálico de 2 frases no topo do conteúdo (para facilitar a extração de dados por rastreadores de IA).
   - FAQ de IA (Perguntas Frequentes): Adicione uma seção de 'Perguntas Frequentes' com 3 perguntas e respostas diretas e curtas no final do texto (para facilitar a citação direta por motores de RAG).
   - Tabelas de Comparação / Detalhes: Se for um produto ou post comparativo, utilize listas ou tabelas HTML estruturadas para detalhar especificações técnicas de forma clara.
9. Links Internos: Você DEVE inserir links de hipertexto HTML (<a href='URL'>Texto Ancora</a>) apontando para os links internos da nossa lista abaixo quando os termos correspondentes forem mencionados, de forma natural e fluída no conteúdo:
{$links_prompt}
10. Link de Saída (Outbound Link): Insira pelo menos um link de saída HTML (<a href='...'>) apontando para uma fonte externa de autoridade confiável e relacionada ao assunto (ex: Wikipédia, portais de notícia ou órgãos oficiais).
11. Resumo / Descrição Curta: Escreva um resumo comercial (100 a 140 caracteres) do item contendo a palavra-chave.
12. Alt Text de Imagem: Sugira um texto alternativo (Alt Text) para a imagem de destaque do item que seja descritivo e inclua a palavra-chave em foco.

Você deve responder APENAS com um objeto JSON válido, contendo as chaves abaixo e NENHUM texto adicional:
{
  \"focus_keyword\": \"Palavra-chave ideal curta\",
  \"seo_title\": \"Título de 50 a 60 caracteres\",
  \"meta_description\": \"Meta descrição de 120 a 160 caracteres\",
  \"optimized_content\": \"Conteúdo HTML completo estruturado, iniciando com o TL;DR, seguido do corpo do texto com H2/H3 e links, e finalizando com a seção FAQ (com tags H2, H3, p, a, ul, li, table, tr, td)\",
  \"short_description\": \"Resumo ou descrição curta\",
  \"image_alt\": \"Alt text de imagem descritivo\"
}";
        } else {
            $lang_map = [
                'es' => 'Spanish',
                'fr' => 'French',
                'it' => 'Italian',
                'de' => 'German',
                'en' => 'English'
            ];
            $lang_name = isset($lang_map[$locale_short]) ? $lang_map[$locale_short] : 'English';

            $system_instruction = "You are a High-Level Expert in Technical SEO, GEO (Generative Engine Optimization), and Copywriting for AIs.
Your mission is to optimize posts, pages, and products based on classic SEO, E-E-A-T, and Response Engine Optimization (like ChatGPT Search, Claude, and Perplexity):

1. Language: All generated content (including focus_keyword, seo_title, meta_description, optimized_content, short_description, and image_alt) must be written in {$lang_name}.
2. E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness): The rewritten content must demonstrate deep technical knowledge. Avoid generic phrases and AI clichés.
3. Readability and Length (Yoast Readability):
   - The final text must be detailed, comprehensive, and exactly between 350 and 600 words.
   - Sentence Length: Keep sentences short and direct (maximum of 20 words per sentence). Avoid long, run-on sentences. At least 75% of sentences must have fewer than 20 words.
   - Transition Words: Use a very high density of transition words (such as 'furthermore', 'therefore', 'however', 'consequently', 'for example', 'thus', 'on the other hand', 'additionally', 'moreover', 'as a result') to connect sentences and paragraphs smoothly. At least 30% of generated sentences must contain transition words to pass Yoast readability tests.
4. Focus Keyword: Suggest the ideal focus keyword based on search trends (1 to 4 words max).
5. SEO Title: Create an impactful SEO title with 50 to 60 characters. The focus keyword must be at the beginning of the title.
6. Meta Description: Write a persuasive meta description of 120 to 160 characters containing the focus keyword.
7. Subheading Structure: Organize the text using H2 and H3 logically. At least one H2 or H3 subheading must contain the focus keyword or a very close synonym.
8. GEO (Generative Engine Optimization) & AI Training:
   - TL;DR (Executive Summary): Add a quick 2-sentence summary in italics at the top of the content (for easy crawler data extraction).
   - AI FAQ: Add a 'Frequently Asked Questions' section with 3 direct and short questions and answers at the end of the text (for easy RAG citation).
   - Comparison Tables / Details: If it is a product or comparative post, use HTML tables or lists to detail technical specs clearly.
9. Internal Links: You MUST insert HTML links (<a href='URL'>Anchor Text</a>) pointing to internal links from the list below when relevant terms are mentioned:
{$links_prompt}
10. Outbound Link: Insert at least one HTML outbound link (<a href='...'>) pointing to a trusted external authority source (e.g., Wikipedia).
11. Short Description: Write a short commercial excerpt (100 to 140 characters) containing the focus keyword.
12. Image Alt Text: Suggest descriptive alternative text (Alt Text) for the featured image containing the focus keyword.

You must respond ONLY with a valid JSON object containing the keys below and NO other text:
{
  \"focus_keyword\": \"Ideal short focus keyword\",
  \"seo_title\": \"SEO title of 50 to 60 characters\",
  \"meta_description\": \"Meta description of 120 to 160 characters\",
  \"optimized_content\": \"Full HTML structured content, starting with the TL;DR, followed by the text body with H2/H3 and links, and ending with the FAQ section (using H2, H3, p, a, ul, li, table, tr, td)\",
  \"short_description\": \"Short excerpt or description\",
  \"image_alt\": \"Descriptive image alt text\"
}";
        }

        $prompt = "Optimize this entry using real search data:\nType: {$post_type}\nTitle: {$title}\nCategories: {$cat_list}\nOriginal Content: {$content}";

        $seo_data = $this->call_ai_api($prompt, $system_instruction);
        if (is_wp_error($seo_data)) {
            return $seo_data;
        }

        // Apply optimizations to Database
        remove_action('save_post', [$this, 'auto_optimize_on_save'], 99);

        // Update post title/content/excerpt
        $updated_post = [
            'ID' => $post_id,
            'post_content' => wp_kses_post($seo_data['optimized_content']),
        ];
        
        if (!empty($seo_data['short_description'])) {
            $updated_post['post_excerpt'] = sanitize_text_field($seo_data['short_description']);
        }
        
        wp_update_post($updated_post);

        // Update Yoast SEO Fields
        update_post_meta($post_id, '_yoast_wpseo_focuskw', sanitize_text_field($seo_data['focus_keyword']));
        update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_text_field($seo_data['meta_description']));
        update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($seo_data['seo_title']));

        // Update Rank Math SEO Fields
        update_post_meta($post_id, 'rank_math_focus_keyword', sanitize_text_field($seo_data['focus_keyword']));
        update_post_meta($post_id, 'rank_math_description', sanitize_text_field($seo_data['meta_description']));
        update_post_meta($post_id, 'rank_math_title', sanitize_text_field($seo_data['seo_title']));

        // Update Indexable database score directly to 90 (Green/Good)
        global $wpdb;
        $table_name = $wpdb->prefix . 'yoast_indexable';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
            $wpdb->update(
                $table_name,
                [
                    'primary_focus_keyword' => sanitize_text_field($seo_data['focus_keyword']),
                    'primary_focus_keyword_score' => 90,
                    'readability_score' => 90,
                    'title' => sanitize_text_field($seo_data['seo_title']),
                    'description' => sanitize_text_field($seo_data['meta_description'])
                ],
                ['object_id' => $post_id, 'object_type' => 'post']
            );
        }

        // If featured image exists, set its alt text
        $thumbnail_id = get_post_thumbnail_id($post_id);
        if ($thumbnail_id && !empty($seo_data['image_alt'])) {
            update_post_meta($thumbnail_id, '_wp_attachment_image_alt', sanitize_text_field($seo_data['image_alt']));
        }

        // Restore save_post hook
        add_action('save_post', [$this, 'auto_optimize_on_save'], 99, 3);

        return [
            'keyword' => $seo_data['focus_keyword'],
            'title'   => $seo_data['seo_title'],
            'meta'    => $seo_data['meta_description']
        ];
    }

    /**
     * Hook: Auto-optimize on Save
     */
    public function auto_optimize_on_save($post_id, $post, $update) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        if ($post->post_status === 'auto-draft') return;

        $auto_optimize = get_option('ai_seo_auto_optimize', 'no');
        if ($auto_optimize !== 'yes') {
            return;
        }

        $selected_types = get_option('ai_seo_post_types', ['post', 'page', 'product']);
        if (!in_array($post->post_type, $selected_types)) {
            return;
        }

        $this->optimize_post_seo($post_id);
    }

    /**
     * Hook: Clean image filename on upload to match SEO rules (no spaces, special chars, etc.)
     */
    public function seo_rename_upload_filename($file) {
        $rename_images = get_option('ai_seo_rename_images', 'no');
        if ($rename_images !== 'yes') {
            return $file;
        }

        $info = pathinfo($file['name']);
        $ext  = empty($info['extension']) ? '' : '.' . $info['extension'];
        $name = basename($file['name'], $ext);

        $clean_name = sanitize_title($name);
        $file['name'] = $clean_name . $ext;

        return $file;
    }

    /**
     * Hook: Set uploaded image metadata (Alt Text, Title, Description) using post parent info
     */
    public function seo_set_image_metadata($post_id) {
        $rename_images = get_option('ai_seo_rename_images', 'no');
        if ($rename_images !== 'yes') {
            return;
        }

        $attachment = get_post($post_id);
        if (!$attachment || empty($attachment->post_parent)) {
            return;
        }

        $parent_id = $attachment->post_parent;
        $parent = get_post($parent_id);
        if (!$parent) {
            return;
        }

        $parent_title = $parent->post_title;
        $alt_text = sprintf(__('Imagem de %s - Otimizada por IA', 'universal-ai-seo'), $parent_title);
        
        update_post_meta($post_id, '_wp_attachment_image_alt', sanitize_text_field($alt_text));

        wp_update_post([
            'ID'           => $post_id,
            'post_title'   => sanitize_text_field($parent_title),
            'post_content' => sanitize_text_field($alt_text)
        ]);
    }

    /**
     * String normalization helper
     */
    private function lowercase_without_accents($str) {
        $str = mb_strtolower($str, 'UTF-8');
        $unwanted_array = array(
            'á'=>'a', 'à'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
            'é'=>'e', 'è'=>'e', 'ê'=>'e', 'ë'=>'e', 'í'=>'i', 'ì'=>'i', 'î'=>'i', 'ï'=>'i',
            'ñ'=>'n', 'ó'=>'o', 'ò'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ú'=>'u',
            'ù'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y', 'ÿ'=>'y',
        );
        return strtr($str, $unwanted_array);
    }

    /**
     * Local site relationship graph query to select top 8 relevant internal links
     */
    private function get_related_internal_links($post_id, $post_title, $post_content) {
        $links = [];
        
        // 1. Get all product categories
        $product_cats = get_terms([
            'taxonomy' => 'product_cat',
            'hide_empty' => true,
        ]);
        if (!is_wp_error($product_cats) && !empty($product_cats)) {
            foreach ($product_cats as $cat) {
                $links[] = [
                    'anchor' => $cat->name,
                    'url' => get_term_link($cat),
                    'type' => 'category'
                ];
            }
        }

        // 2. Get main pages
        $pages = get_posts([
            'post_type' => 'page',
            'posts_per_page' => 20,
            'post__not_in' => [$post_id],
        ]);
        foreach ($pages as $p) {
            $links[] = [
                'anchor' => $p->post_title,
                'url' => get_permalink($p->ID),
                'type' => 'page'
            ];
        }

        // 3. Get a few products or posts
        $recent_items = get_posts([
            'post_type' => ['product', 'post'],
            'posts_per_page' => 30,
            'post__not_in' => [$post_id],
        ]);
        foreach ($recent_items as $item) {
            $links[] = [
                'anchor' => $item->post_title,
                'url' => get_permalink($item->ID),
                'type' => 'item'
            ];
        }

        // Match terms in title and content to rank them
        $text_to_match = $this->lowercase_without_accents($post_title . ' ' . $post_content);
        
        $scored_links = [];
        foreach ($links as $l) {
            $anchor_lower = $this->lowercase_without_accents($l['anchor']);
            $score = 0;
            if (strpos($text_to_match, $anchor_lower) !== false) {
                $score += 10; // direct mention
            }
            
            // Check word overlap
            $words = explode(' ', $anchor_lower);
            foreach ($words as $w) {
                if (strlen($w) > 3 && strpos($text_to_match, $w) !== false) {
                    $score += 2;
                }
            }
            
            if ($score > 0) {
                $l['score'] = $score;
                $scored_links[] = $l;
            }
        }
        
        // Sort by score descending
        usort($scored_links, function($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        
        // Take top 8
        $selected = array_slice($scored_links, 0, 8);
        
        // Fallback to top categories/pages if no matches
        if (empty($selected)) {
            $selected = array_slice($links, 0, 5);
        }
        
        return $selected;
    }

    /**
     * Generate the Knowledge Graph array representing the site
     */
    private function generate_site_graph_data() {
        $nodes = [];
        $edges = [];

        // 1. Export WooCommerce Product Categories
        $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false]);
        if (!is_wp_error($categories)) {
            foreach ($categories as $cat) {
                $nodes[] = [
                    'id' => 'cat_' . $cat->term_id,
                    'label' => $cat->name,
                    'type' => 'category',
                    'url' => get_term_link($cat),
                    'description' => $cat->description ? $cat->description : 'Categoria de produtos ' . $cat->name
                ];
            }
        }
        
        // 2. Export Standard Post Categories
        $post_categories = get_terms(['taxonomy' => 'category', 'hide_empty' => false]);
        if (!is_wp_error($post_categories)) {
            foreach ($post_categories as $cat) {
                $nodes[] = [
                    'id' => 'post_cat_' . $cat->term_id,
                    'label' => $cat->name,
                    'type' => 'category',
                    'url' => get_term_link($cat),
                    'description' => $cat->description ? $cat->description : 'Categoria de postagens ' . $cat->name
                ];
            }
        }

        // 3. Export Posts, Pages, Products
        $selected_types = get_option('ai_seo_post_types', ['post', 'page', 'product']);
        $query = new WP_Query([
            'post_type' => $selected_types,
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ]);

        if ($query->have_posts()) {
            foreach ($query->posts as $post) {
                $excerpt = $post->post_excerpt ? $post->post_excerpt : substr(wp_strip_all_tags($post->post_content), 0, 200);
                
                $nodes[] = [
                    'id' => 'post_' . $post->ID,
                    'label' => $post->post_title,
                    'type' => $post->post_type,
                    'url' => get_permalink($post->ID),
                    'description' => wp_strip_all_tags($excerpt)
                ];

                // Add edges for Categories relationships
                if ($post->post_type === 'product') {
                    $terms = get_the_terms($post->ID, 'product_cat');
                    if ($terms && !is_wp_error($terms)) {
                        foreach ($terms as $t) {
                            $edges[] = [
                                'source' => 'post_' . $post->ID,
                                'target' => 'cat_' . $t->term_id,
                                'type' => 'belongs_to'
                            ];
                        }
                    }
                } else {
                    $terms = get_the_terms($post->ID, 'category');
                    if ($terms && !is_wp_error($terms)) {
                        foreach ($terms as $t) {
                            $edges[] = [
                                'source' => 'post_' . $post->ID,
                                'target' => 'post_cat_' . $t->term_id,
                                'type' => 'belongs_to'
                            ];
                        }
                    }
                }
            }
        }

        return [
            'nodes' => $nodes,
            'edges' => $edges
        ];
    }

    /**
     * Generate the markdown report of the graph
     */
    private function generate_site_graph_report_content($nodes, $edges) {
        $report_content = "# Conext Knowledge Graph Report\n\n";
        $report_content .= "Generated automatically on: " . current_time('mysql') . "\n";
        $report_content .= "Total Nodes (Entities): " . count($nodes) . "\n";
        $report_content .= "Total Edges (Relationships): " . count($edges) . "\n\n";
        $report_content .= "This file lists all structural entities and relationships extracted from this WordPress website to be utilized directly by LLMs (ChatGPT, Claude, Perplexity) for RAG or training.\n\n";
        $report_content .= "## Nodes Summary\n";
        foreach ($nodes as $n) {
            $report_content .= "- **{$n['label']}** (Type: `{$n['type']}`) - [Visit Link]({$n['url']}) - *{$n['description']}*\n";
        }
        return $report_content;
    }
}

// Flush rewrites on Activation/Deactivation
register_activation_hook(__FILE__, function() {
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules();
});

// Instantiate
add_action('plugins_loaded', function() {
    Conext_AI_SEO_Optimizer::instance();
});
